from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
import requests
API_KEY = "919d52599a7c4c8689e51d1c9380ba85"


def home(request):
    #url = f'https://newsapi.org/v2/top-headlines?country=us&apikey={API_KEY}'
    CountryR = request.GET.get('country')

    if CountryR:
        url= f'https://newsapi.org/v2/top-headlines?country={CountryR}&apikey={API_KEY}'
    else:
        url= f'https://newsapi.org/v2/top-headlines?country=us&apikey={API_KEY}'


    response = requests.get(url)
    data = response.json()
    articles = data['articles']
    context = {
       #y原来的 'articles':data['articles']
             'articles': articles
    }
    print(context)
    
    return render(request,'newsapp/home.html',context)
    #return HttpResponse("Hello World!You are at home of my news app")